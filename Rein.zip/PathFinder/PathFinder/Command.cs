#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
#endregion

namespace PathFinder
{

    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    [Journaling(JournalingMode.NoCommandData)]
    public class Command : IExternalCommand
    {
        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Application app = uiapp.Application;
            Document doc = uidoc.Document;

            // Access current selection

            Selection sel = uidoc.Selection;

            Reference pickedObj = sel.PickObject(ObjectType.Element, "Please select an element to copy.");
            Element element = doc.GetElement(pickedObj.ElementId);
            Wall wall = element as Wall;

            findInsets(doc, wall);

            PathReinforcement rein1 = null;
            PathReinforcement rein2 = null;

            PathReinforcement rein3 = null;
            PathReinforcement rein4 = null;
            PathReinforcement rein5 = null;
            PathReinforcement rein6 = null;

            PathReinforcement rein7 = null;
            PathReinforcement rein8 = null;

            ElementId hookId = null;

            FilteredElementCollector collector = new FilteredElementCollector(doc).OfClass(typeof(RebarHookType));

            foreach (RebarHookType hType in collector)
            {
                if (hType.Id.ToString() == "648153")
                {
                    hookId = hType.Id;
                }
            }

            using (Transaction tx = new Transaction(doc))
            {
                tx.Start("Transaction Name");

                FailureHandlingOptions options = tx.GetFailureHandlingOptions();
                WarningSuppressor preproccessor = new WarningSuppressor();
                options.SetClearAfterRollback(true);
                options.SetFailuresPreprocessor(preproccessor);
                tx.SetFailureHandlingOptions(options);

                rein1 = createVerticalPathReinforcement(doc, wall);
                rein2 = createVerticalPathReinforcement(doc, wall);
                rein3 = createHorizontalPathReinforcementLeft(doc, wall, hookId);
                rein4 = createHorizontalPathReinforcementLeft(doc, wall, hookId);
                rein5 = createHorizontalPathReinforcementRight(doc, wall, hookId);
                rein6 = createHorizontalPathReinforcementRight(doc, wall, hookId);
                rein7 = createHorizontalPathReinforcement(doc, wall);
                rein8 = createHorizontalPathReinforcement(doc, wall);

                tx.Commit();
            }

            IList<Parameter> parameters1 = rein1.GetOrderedParameters();
            IList<Parameter> parameters2 = rein2.GetOrderedParameters();
            IList<Parameter> parameters3 = rein3.GetOrderedParameters();
            IList<Parameter> parameters4 = rein4.GetOrderedParameters();
            IList<Parameter> parameters5 = rein5.GetOrderedParameters();
            IList<Parameter> parameters6 = rein6.GetOrderedParameters();
            IList<Parameter> parameters7 = rein7.GetOrderedParameters();
            IList<Parameter> parameters8 = rein8.GetOrderedParameters();

            using (Transaction tx = new Transaction(doc))
            {
                tx.Start("Parametrize");

                foreach (Parameter par in parameters1)
                {
                    if (par.Id.ToString() == "-1018302") // bar spacing
                    {
                        par.SetValueString("400");
                    }
                    if (par.Id.ToString() == "-1018301") // face type
                    {
                        par.Set(0);
                    }
                    if (par.Id.ToString() == "-1018307") // pri bar length
                    {
                        par.SetValueString("3500");
                    }
                    /*
                    if (par.Id.ToString() == "-1018001") // layout rule
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018303") // number of bars
                    {
                        par.Set(9);
                    }
                    */

                }

                foreach (Parameter par in parameters2)
                {

                    if (par.Id.ToString() == "-1018302") // bar spacing
                    {
                        par.SetValueString("400");

                    }
                    if (par.Id.ToString() == "-1018301") // face type
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018307") // pri bar length
                    {
                        par.SetValueString("3500");
                    }
                    /*
                    if (par.Id.ToString() == "-1018001") // layout rule
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018303") // number of bars
                    {
                        par.Set(9);
                    }
                     */

                }

                foreach (Parameter par in parameters3)
                {

                    if (par.Id.ToString() == "-1018302") // bar spacing
                    {
                        par.SetValueString("400");

                    }
                    if (par.Id.ToString() == "-1018301") // face type
                    {
                        par.Set(0);
                    }
                    if (par.Id.ToString() == "-1018307") // pri bar length
                    {
                        par.SetValueString("500");
                    }
                    /*
                    if (par.Id.ToString() == "-1018001") // layout rule
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018303") // number of bars
                    {
                        par.Set(9);
                    }
                   */
                }

                foreach (Parameter par in parameters4)
                {

                    if (par.Id.ToString() == "-1018302") // bar spacing
                    {
                        par.SetValueString("400");

                    }
                    if (par.Id.ToString() == "-1018301") // face type
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018307") // pri bar length
                    {
                        par.SetValueString("500");
                    }
                 
                    /* 2
                    if (par.Id.ToString() == "-1018001") // layout rule
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018303") // number of bars
                    {
                        par.Set(9);
                    }
                   */
                }

                foreach (Parameter par in parameters5)
                {

                    if (par.Id.ToString() == "-1018302") // bar spacing
                    {
                        par.SetValueString("400");

                    }
                    if (par.Id.ToString() == "-1018301") // face type
                    {
                        par.Set(0);
                    }
                    if (par.Id.ToString() == "-1018307") // pri bar length
                    {
                        par.SetValueString("500");
                    }

                    /* 2
                    if (par.Id.ToString() == "-1018001") // layout rule
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018303") // number of bars
                    {
                        par.Set(9);
                    }
                   */
                }

                foreach (Parameter par in parameters6)
                {

                    if (par.Id.ToString() == "-1018302") // bar spacing
                    {
                        par.SetValueString("400");

                    }
                    if (par.Id.ToString() == "-1018301") // face type
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018307") // pri bar length
                    {
                        par.SetValueString("500");
                    }

                    /* 2
                    if (par.Id.ToString() == "-1018001") // layout rule
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018303") // number of bars
                    {
                        par.Set(9);
                    }
                   */
                }

                foreach (Parameter par in parameters7)
                {

                    if (par.Id.ToString() == "-1018302") // bar spacing
                    {
                        par.SetValueString("400");

                    }
                    if (par.Id.ToString() == "-1018301") // face type
                    {
                        par.Set(0);
                    }
                    if (par.Id.ToString() == "-1018307") // pri bar length
                    {
                        par.SetValueString("2990");
                    }

                    /* 2
                    if (par.Id.ToString() == "-1018001") // layout rule
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018303") // number of bars
                    {
                        par.Set(9);
                    }
                   */
                }

                foreach (Parameter par in parameters8)
                {

                    if (par.Id.ToString() == "-1018302") // bar spacing
                    {
                        par.SetValueString("400");

                    }
                    if (par.Id.ToString() == "-1018301") // face type
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018307") // pri bar length
                    {
                        par.SetValueString("2990");
                    }

                    /* 2
                    if (par.Id.ToString() == "-1018001") // layout rule
                    {
                        par.Set(1);
                    }
                    if (par.Id.ToString() == "-1018303") // number of bars
                    {
                        par.Set(9);
                    }
                   */
                }

                tx.Commit();
            }

            

            return Result.Succeeded;
        }
        PathReinforcement createVerticalPathReinforcement(Document document, Wall wall)
        {
            // Create a geometry line in the selected wall as the path
            List<Curve> curves = new List<Curve>();
            LocationCurve location = wall.Location as LocationCurve;
            XYZ start = location.Curve.GetEndPoint(0);
            XYZ end = location.Curve.GetEndPoint(1);

            XYZ start2 = new XYZ(start.X, start.Y, start.Z - 10);
            XYZ end2 = new XYZ(end.X, end.Y, end.Z - 10);

            curves.Add(Line.CreateBound(end2, start2));

            // Obtain the default types
            ElementId defaultRebarBarTypeId = document.GetDefaultElementTypeId(ElementTypeGroup.RebarBarType);
            ElementId defaultPathReinforcementTypeId = document.GetDefaultElementTypeId(ElementTypeGroup.PathReinforcementType);
            ElementId defaultHookTypeId = ElementId.InvalidElementId;


            // Begin to create the path reinforcement
            PathReinforcement rein = PathReinforcement.Create(document, wall, curves, true, defaultPathReinforcementTypeId, defaultRebarBarTypeId, defaultHookTypeId, defaultHookTypeId);
            if (null == rein)
            {
                throw new Exception("Create path reinforcement failed.");
            }

            // Give the user some information
            //TaskDialog.Show("Revit", "Create path reinforcement succeed.");

            return rein;
        }

        PathReinforcement createHorizontalPathReinforcement(Document document, Wall wall)
        {

            // Create a geometry line in the selected wall as the path
            List<Curve> curves = new List<Curve>();
            LocationCurve location = wall.Location as LocationCurve;

            XYZ start = location.Curve.GetEndPoint(0);
            XYZ startNew = new XYZ(start.X, start.Y, start.Z + 0.05);
            XYZ start2 = new XYZ(start.X, start.Y, start.Z - 10.05);

            curves.Add(Line.CreateBound(start2, startNew));

            // Obtain the default types
            ElementId defaultRebarBarTypeId = document.GetDefaultElementTypeId(ElementTypeGroup.RebarBarType);
            ElementId defaultPathReinforcementTypeId = document.GetDefaultElementTypeId(ElementTypeGroup.PathReinforcementType);
            ElementId defaultHookTypeId = ElementId.InvalidElementId;

            // Begin to create the path reinforcement
            PathReinforcement rein = PathReinforcement.Create(document, wall, curves, true, defaultPathReinforcementTypeId, defaultRebarBarTypeId, defaultHookTypeId, defaultHookTypeId);
            if (null == rein)
            {
                throw new Exception("Create path reinforcement failed.");
            }

            return rein;
        }

        PathReinforcement createHorizontalPathReinforcementLeft(Document document, Wall wall, ElementId hookId)
        {

            // Create a geometry line in the selected wall as the path
            List<Curve> curves = new List<Curve>();
            LocationCurve location = wall.Location as LocationCurve;

            XYZ start = location.Curve.GetEndPoint(0);
            XYZ end = location.Curve.GetEndPoint(1);

            XYZ start2 = new XYZ(start.X, start.Y, start.Z - 10);
            XYZ end2 = new XYZ(end.X, end.Y, end.Z - 10);

            curves.Add(Line.CreateBound(start2, start));


            // Obtain the default types
            ElementId defaultRebarBarTypeId = document.GetDefaultElementTypeId(ElementTypeGroup.RebarBarType);
            ElementId defaultPathReinforcementTypeId = document.GetDefaultElementTypeId(ElementTypeGroup.PathReinforcementType);
            ElementId defaultHookTypeId = hookId;

            // Begin to create the path reinforcement
            PathReinforcement rein = PathReinforcement.Create(document, wall, curves, true, defaultPathReinforcementTypeId, defaultRebarBarTypeId, defaultHookTypeId, defaultHookTypeId);
            if (null == rein)
            {
                throw new Exception("Create path reinforcement failed.");
            }

            return rein;
        }

        PathReinforcement createHorizontalPathReinforcementRight(Document document, Wall wall, ElementId hookId)
        {

            // Create a geometry line in the selected wall as the path
            List<Curve> curves = new List<Curve>();
            LocationCurve location = wall.Location as LocationCurve;

            XYZ start = location.Curve.GetEndPoint(0);
            XYZ end = location.Curve.GetEndPoint(1);

            XYZ start2 = new XYZ(start.X, start.Y, start.Z - 10);
            XYZ end2 = new XYZ(end.X, end.Y, end.Z - 10);

            curves.Add(Line.CreateBound(end, end2));


            // Obtain the default types
            ElementId defaultRebarBarTypeId = document.GetDefaultElementTypeId(ElementTypeGroup.RebarBarType);
            ElementId defaultPathReinforcementTypeId = document.GetDefaultElementTypeId(ElementTypeGroup.PathReinforcementType);
            ElementId defaultHookTypeId = hookId;

            // Begin to create the path reinforcement
            PathReinforcement rein = PathReinforcement.Create(document, wall, curves, true, defaultPathReinforcementTypeId, defaultRebarBarTypeId, defaultHookTypeId, defaultHookTypeId);
            if (null == rein)
            {
                throw new Exception("Create path reinforcement failed.");
            }

            return rein;
        }

        void findInsets(Document doc, Wall wall)
        {
            var ids = wall.FindInserts(true, true, true, true);
            foreach (ElementId id in ids)
            {
                var el = doc.GetElement(id);

                LocationCurve wallCurve = wall.Location as LocationCurve;
                XYZ start = wallCurve.Curve.GetEndPoint(0);
                XYZ end = wallCurve.Curve.GetEndPoint(1);

                XYZ p = null;
                Util.GetElementLocation(out p, el);

                Debug.Print(start.X.ToString() + " " + start.Y.ToString() + " " + start.Z.ToString());
                Debug.Print(end.X.ToString() + " " + end.Y.ToString() + " " + end.Z.ToString());
                Debug.Print(p.X.ToString() + " " + p.Y.ToString() + " " + p.Z.ToString());

                Debug.WriteLine(" Id: " + el.Id);
                Debug.WriteLine(" Type: " + el.GetType().Name);
                Debug.WriteLine(" Category: " + el.Category.Name);
                Debug.WriteLine(" Type: " + el.GetType().Name);

                if (el is FamilyInstance)
                {
                    var fi = el as FamilyInstance;
                    if (fi != null)
                        Debug.WriteLine(" Symbol Name: " + fi.Symbol.Name);
                }
            }
        }
    }

}