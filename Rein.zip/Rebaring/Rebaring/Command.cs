#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI.Selection;
using System.Linq;
using Autodesk.Revit.DB.Mechanical;
#endregion

namespace Rebaring
{
    [Transaction(TransactionMode.Manual)]
    public class Command : IExternalCommand
    {
        public Result Execute(
          ExternalCommandData commandData,
          ref string message,
          ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Application app = uiapp.Application;
            Document doc = uidoc.Document;
            View myActiveView = doc.ActiveView;

            // Access current selection

            Selection sel = uidoc.Selection;

            Options options = new Options
            {
                ComputeReferences = true
            };

            Reference pickedObj = sel.PickObject(ObjectType.Element, "Please select an element to copy.");
            ElementId id = pickedObj.ElementId;
            Element element = doc.GetElement(pickedObj.ElementId);
            Wall wall = element as Wall;
            var bounds = wall.get_BoundingBox(null);
            var i = element.GetParameters(BuiltInParameter.WALL_BASE_CONSTRAINT.ToString());
            IList<Element> wallFS = new List<Element> 
                (new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_Walls)
                .OfClass(typeof(Wall)));


            GeometryElement geoElement = wall.get_Geometry(options);
            Face face = null;
            foreach (GeometryObject geomObj in geoElement)
            {
                Solid geomSolid = geomObj as Solid;
                if (null != geomSolid)
                {
                    foreach (Face geomFace in geomSolid.Faces)
                    {
                        face = geomFace;
                        break;
                    }
                    break;
                }
            }
            //Then get the target face from the geoElement object.

           /* FamilySymbol fs = wallFS[7] as FamilySymbol;
            Debug.Print(wallFS.ToString());
            using (Transaction tx = new Transaction(doc))
            {
                tx.Start("activate Symbol");
                fs.Activate();
                tx.Commit();
            }
            */

            LocationCurve locCurve = wall.Location as LocationCurve;
            Line line = locCurve.Curve as Line;
            XYZ point1 = line.GetEndPoint(0);
            XYZ point2 = line.GetEndPoint(1);

            //IList<Reference> refs = HostObjectUtils.GetSideFaces(wall, ShellLayerType.Exterior);
            
          
           //FamilyInstance fi = doc.Create.NewFamilyInstance(face, point1, point2, fs);

            using (Transaction tx = new Transaction(doc))
            {
                tx.Start("Transaction Name");
                CreateRebar(doc, wall.Location, RebarBarType.Create(doc), RebarHookType.Create(doc, Math.PI / 2, 0.4), element);
                tx.Commit();
            }

            return Result.Succeeded;
        }

        Rebar CreateRebar(Document document, Location loc, RebarBarType barType, RebarHookType hookType, Element el)
        {
            // Define the rebar geometry information - Line rebar
            LocationPoint location = loc as LocationPoint;
            XYZ origin = location.Point;
            XYZ normal = new XYZ(1, 0, 0);
            // create rebar 9' long
            XYZ rebarLineEnd = new XYZ(origin.X, origin.Y, origin.Z + 9);
            Line rebarLine = Line.CreateBound(origin, rebarLineEnd);

            // Create the line rebar
            IList<Curve> curves = new List<Curve>();
            curves.Add(rebarLine);


            Rebar rebar = Rebar.CreateFromCurves(document, RebarStyle.Standard, barType, hookType, hookType,
                                el, origin, curves, RebarHookOrientation.Right, RebarHookOrientation.Left, true, true);

            if (null != rebar)
            {
                // set specific layout for new rebar as fixed number, with 10 bars, distribution path length of 1.5'
                // with bars of the bar set on the same side of the rebar plane as indicated by normal
                // and both first and last bar in the set are shown
                rebar.SetLayoutAsFixedNumber(10, 1.5, true, true, true);
            }

            return rebar;
        }
    }
}
